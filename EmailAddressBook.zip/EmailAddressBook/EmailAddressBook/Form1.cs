﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace EmailAddressBook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Create object from PersonEntry class for each person's data
                PersonEntry personData = new PersonEntry();

                // List to hold object of each person
                List<string> personList = new List<string>();

                const int SIZE = 10;
                string[] addressBookList = new string[SIZE];        // Holds the information read from file

                StreamReader savedAddressContact;       // Information of contacts 

                savedAddressContact = File.OpenText("addressbook.txt");         // Open the text file

                int i = 0;
                char[] delim = { ',' };
                while (i < addressBookList.Length && !savedAddressContact.EndOfStream)
                {
                    addressBookList[i] = savedAddressContact.ReadLine();
                    string[] tokens = addressBookList[i].Split(delim);
                    personData.Name = tokens[i];
                    personData.Email = tokens[i + 1];
                    personData.Number = tokens[i + 2];

                    nameListBox.Items.Add(personData.Name);
                }

                string selection;
                PersonContactInfo selectedContact = new PersonContactInfo();
                if (nameListBox.SelectedIndex == 0)
                {
                    //PersonContactInfo.nameLabel.Text = "Alex";
                    selectedContact.ShowDialog();
                }
                else if (nameListBox.SelectedIndex == 1)
                {
                    selectedContact.ShowDialog();
                }
                else if (nameListBox.SelectedIndex == 2)
                {
                    selectedContact.ShowDialog();
                }
                else if (nameListBox.SelectedIndex == 3)
                {
                    selectedContact.ShowDialog();
                }
                else
                {
                    selectedContact.ShowDialog();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
