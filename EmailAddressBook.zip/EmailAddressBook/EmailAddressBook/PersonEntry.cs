﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailAddressBook
{
    class PersonEntry
    {
        string name;        // Name of contact
        string email;       // Email of contact
        string number;      // Phone number of contact

        public PersonEntry()
        {
            name = "";
            email = "";
            number = "";
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Number
        {
            get { return number; }
            set { number = value; }
        }
    }
}
