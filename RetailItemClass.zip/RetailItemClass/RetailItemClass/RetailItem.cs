﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClass
{
    class RetailItem
    {
        private string description;
        private int unitsOnHand;
        private double price;
        //string clothing, int units, double cost
        public RetailItem(string descript, int units, double cost)
        {
            description = descript;
            unitsOnHand = units;
            price = cost;
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int UnitsOnHand
        {
            get { return unitsOnHand; }
            set { unitsOnHand = value; }
        }

        public double Price
        {
            get { return price; }
            set { price = value; }
        }
    }
}
