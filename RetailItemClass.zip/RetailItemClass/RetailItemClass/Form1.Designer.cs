﻿namespace RetailItemClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.descriptionOneLabel = new System.Windows.Forms.Label();
            this.descriptionTwoLabel = new System.Windows.Forms.Label();
            this.descriptionThreeLabel = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.unitOneLabel = new System.Windows.Forms.Label();
            this.unitTwoLabel = new System.Windows.Forms.Label();
            this.unitThreeLabel = new System.Windows.Forms.Label();
            this.priceThreeLabel = new System.Windows.Forms.Label();
            this.priceTwoLabel = new System.Windows.Forms.Label();
            this.priceOneLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Description";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(162, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Units on Hand";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(258, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Item 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Item 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Item 3";
            // 
            // descriptionOneLabel
            // 
            this.descriptionOneLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.descriptionOneLabel.Location = new System.Drawing.Point(54, 55);
            this.descriptionOneLabel.Name = "descriptionOneLabel";
            this.descriptionOneLabel.Size = new System.Drawing.Size(95, 23);
            this.descriptionOneLabel.TabIndex = 6;
            this.descriptionOneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // descriptionTwoLabel
            // 
            this.descriptionTwoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.descriptionTwoLabel.Location = new System.Drawing.Point(54, 101);
            this.descriptionTwoLabel.Name = "descriptionTwoLabel";
            this.descriptionTwoLabel.Size = new System.Drawing.Size(95, 23);
            this.descriptionTwoLabel.TabIndex = 9;
            this.descriptionTwoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // descriptionThreeLabel
            // 
            this.descriptionThreeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.descriptionThreeLabel.Location = new System.Drawing.Point(54, 146);
            this.descriptionThreeLabel.Name = "descriptionThreeLabel";
            this.descriptionThreeLabel.Size = new System.Drawing.Size(95, 23);
            this.descriptionThreeLabel.TabIndex = 12;
            this.descriptionThreeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(54, 192);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 23);
            this.displayButton.TabIndex = 15;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(205, 192);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 16;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // unitOneLabel
            // 
            this.unitOneLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.unitOneLabel.Location = new System.Drawing.Point(165, 55);
            this.unitOneLabel.Name = "unitOneLabel";
            this.unitOneLabel.Size = new System.Drawing.Size(72, 23);
            this.unitOneLabel.TabIndex = 17;
            this.unitOneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // unitTwoLabel
            // 
            this.unitTwoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.unitTwoLabel.Location = new System.Drawing.Point(165, 101);
            this.unitTwoLabel.Name = "unitTwoLabel";
            this.unitTwoLabel.Size = new System.Drawing.Size(72, 23);
            this.unitTwoLabel.TabIndex = 18;
            this.unitTwoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // unitThreeLabel
            // 
            this.unitThreeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.unitThreeLabel.Location = new System.Drawing.Point(165, 146);
            this.unitThreeLabel.Name = "unitThreeLabel";
            this.unitThreeLabel.Size = new System.Drawing.Size(72, 23);
            this.unitThreeLabel.TabIndex = 19;
            this.unitThreeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // priceThreeLabel
            // 
            this.priceThreeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.priceThreeLabel.Location = new System.Drawing.Point(252, 146);
            this.priceThreeLabel.Name = "priceThreeLabel";
            this.priceThreeLabel.Size = new System.Drawing.Size(60, 23);
            this.priceThreeLabel.TabIndex = 20;
            this.priceThreeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // priceTwoLabel
            // 
            this.priceTwoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.priceTwoLabel.Location = new System.Drawing.Point(252, 101);
            this.priceTwoLabel.Name = "priceTwoLabel";
            this.priceTwoLabel.Size = new System.Drawing.Size(60, 23);
            this.priceTwoLabel.TabIndex = 21;
            this.priceTwoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // priceOneLabel
            // 
            this.priceOneLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.priceOneLabel.Location = new System.Drawing.Point(252, 55);
            this.priceOneLabel.Name = "priceOneLabel";
            this.priceOneLabel.Size = new System.Drawing.Size(60, 23);
            this.priceOneLabel.TabIndex = 22;
            this.priceOneLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 227);
            this.Controls.Add(this.priceOneLabel);
            this.Controls.Add(this.priceTwoLabel);
            this.Controls.Add(this.priceThreeLabel);
            this.Controls.Add(this.unitThreeLabel);
            this.Controls.Add(this.unitTwoLabel);
            this.Controls.Add(this.unitOneLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.descriptionThreeLabel);
            this.Controls.Add(this.descriptionTwoLabel);
            this.Controls.Add(this.descriptionOneLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Retail Item";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label descriptionOneLabel;
        private System.Windows.Forms.Label descriptionTwoLabel;
        private System.Windows.Forms.Label descriptionThreeLabel;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label unitOneLabel;
        private System.Windows.Forms.Label unitTwoLabel;
        private System.Windows.Forms.Label unitThreeLabel;
        private System.Windows.Forms.Label priceThreeLabel;
        private System.Windows.Forms.Label priceTwoLabel;
        private System.Windows.Forms.Label priceOneLabel;
    }
}

