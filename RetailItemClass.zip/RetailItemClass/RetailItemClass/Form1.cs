﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RetailItemClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Constant variable of number of items
            const int NUMBEROFITEM = 3;
            RetailItem[] item = new RetailItem[NUMBEROFITEM];

            // Array of clothing, unit, cost
            string[] clothing = { "Jackets", "Jeans", "Shirt" };
            int[] units = { 12, 40, 20 };
            double[] cost = { 59.95, 34.95, 24.95 };

            // Create object
            for (int i = 0; i < NUMBEROFITEM; i++)
            {
                item[i] = new RetailItem(clothing[i], units[i], cost[i]);
            }

            // Get the description of whole item [clothing,unit,cost] of each item
            string[] descriptionResult = new string[NUMBEROFITEM];
            for (int a = 0; a < NUMBEROFITEM; a++)
            {
                descriptionResult[a] = item[a].Description.ToString() + "," + item[a].UnitsOnHand.ToString() + "," + item[a].Price.ToString();
            }

            // Split the description of whole item into parts
            char[] delim = { ',' };
            string[] tokensOne = descriptionResult[0].Split(delim);
            string[] tokensTwo = descriptionResult[1].Split(delim);
            string[] tokensThree = descriptionResult[2].Split(delim);

            // Display for item 1
            descriptionOneLabel.Text = tokensOne[0];
            unitOneLabel.Text = tokensOne[1];
            priceOneLabel.Text = tokensOne[2];

            // Display for item 2
            descriptionTwoLabel.Text = tokensTwo[0];
            unitTwoLabel.Text = tokensTwo[1];
            priceTwoLabel.Text = tokensTwo[2];

            // Display for item 3
            descriptionThreeLabel.Text = tokensThree[0];
            unitThreeLabel.Text = tokensThree[1];
            priceThreeLabel.Text = tokensThree[2];
        }

        // Close the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
