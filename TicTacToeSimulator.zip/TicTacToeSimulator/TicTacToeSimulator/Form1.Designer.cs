﻿namespace TicTacToeSimulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.labelOne = new System.Windows.Forms.Label();
            this.labelTwo = new System.Windows.Forms.Label();
            this.labelThree = new System.Windows.Forms.Label();
            this.labelFour = new System.Windows.Forms.Label();
            this.labelFive = new System.Windows.Forms.Label();
            this.labelSix = new System.Windows.Forms.Label();
            this.labelSeven = new System.Windows.Forms.Label();
            this.labelEight = new System.Windows.Forms.Label();
            this.labelNine = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(30, 288);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 23);
            this.newGameButton.TabIndex = 0;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(161, 288);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // labelOne
            // 
            this.labelOne.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOne.Location = new System.Drawing.Point(30, 29);
            this.labelOne.Name = "labelOne";
            this.labelOne.Size = new System.Drawing.Size(50, 50);
            this.labelOne.TabIndex = 2;
            this.labelOne.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTwo
            // 
            this.labelTwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTwo.Location = new System.Drawing.Point(109, 29);
            this.labelTwo.Name = "labelTwo";
            this.labelTwo.Size = new System.Drawing.Size(50, 50);
            this.labelTwo.TabIndex = 3;
            this.labelTwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelThree
            // 
            this.labelThree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThree.Location = new System.Drawing.Point(186, 29);
            this.labelThree.Name = "labelThree";
            this.labelThree.Size = new System.Drawing.Size(50, 50);
            this.labelThree.TabIndex = 4;
            this.labelThree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelFour
            // 
            this.labelFour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFour.Location = new System.Drawing.Point(30, 102);
            this.labelFour.Name = "labelFour";
            this.labelFour.Size = new System.Drawing.Size(50, 50);
            this.labelFour.TabIndex = 5;
            this.labelFour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelFive
            // 
            this.labelFive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFive.Location = new System.Drawing.Point(109, 102);
            this.labelFive.Name = "labelFive";
            this.labelFive.Size = new System.Drawing.Size(50, 50);
            this.labelFive.TabIndex = 6;
            this.labelFive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSix
            // 
            this.labelSix.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSix.Location = new System.Drawing.Point(186, 102);
            this.labelSix.Name = "labelSix";
            this.labelSix.Size = new System.Drawing.Size(50, 50);
            this.labelSix.TabIndex = 7;
            this.labelSix.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelSeven
            // 
            this.labelSeven.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelSeven.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeven.Location = new System.Drawing.Point(30, 172);
            this.labelSeven.Name = "labelSeven";
            this.labelSeven.Size = new System.Drawing.Size(50, 50);
            this.labelSeven.TabIndex = 8;
            this.labelSeven.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelEight
            // 
            this.labelEight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelEight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEight.Location = new System.Drawing.Point(109, 172);
            this.labelEight.Name = "labelEight";
            this.labelEight.Size = new System.Drawing.Size(50, 50);
            this.labelEight.TabIndex = 9;
            this.labelEight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelNine
            // 
            this.labelNine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelNine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNine.Location = new System.Drawing.Point(186, 172);
            this.labelNine.Name = "labelNine";
            this.labelNine.Size = new System.Drawing.Size(50, 50);
            this.labelNine.TabIndex = 10;
            this.labelNine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // resultLabel
            // 
            this.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.resultLabel.Location = new System.Drawing.Point(30, 242);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(206, 23);
            this.resultLabel.TabIndex = 11;
            this.resultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 325);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.labelNine);
            this.Controls.Add(this.labelEight);
            this.Controls.Add(this.labelSeven);
            this.Controls.Add(this.labelSix);
            this.Controls.Add(this.labelFive);
            this.Controls.Add(this.labelFour);
            this.Controls.Add(this.labelThree);
            this.Controls.Add(this.labelTwo);
            this.Controls.Add(this.labelOne);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label labelOne;
        private System.Windows.Forms.Label labelTwo;
        private System.Windows.Forms.Label labelThree;
        private System.Windows.Forms.Label labelFour;
        private System.Windows.Forms.Label labelFive;
        private System.Windows.Forms.Label labelSix;
        private System.Windows.Forms.Label labelSeven;
        private System.Windows.Forms.Label labelEight;
        private System.Windows.Forms.Label labelNine;
        private System.Windows.Forms.Label resultLabel;
    }
}

