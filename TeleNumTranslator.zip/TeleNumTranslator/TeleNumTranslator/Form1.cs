﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeleNumTranslator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Check the length of the input
        private bool checkValidNumber(string alphabetPhoneNumber)
        {
            const int VALID_NUMBER = 10;
            bool valid = true;

            if (alphabetPhoneNumber.Length == VALID_NUMBER)
            {
                return valid;
            }
            else
                return valid = false;

        }

        // Check each letter and find the corresponding number and add to end result
        private void convertAlphabetToNumeric(string alphabetPhoneNumber)
        {
            string result = "";             // End result string

            for (int i = 0; i < alphabetPhoneNumber.Length; i++)
            {
                char letter = char.ToUpper(alphabetPhoneNumber[i]);
                if (char.IsLetterOrDigit(alphabetPhoneNumber[i]))
                {
                    if (letter == 'A' || letter == 'B' || letter == 'C')
                        result = result + "2";
                    else if (letter == 'D' || letter == 'E' || letter == 'F')
                        result = result + "3";
                    else if (letter == 'G' || letter == 'H' || letter == 'I')
                        result = result + "4";
                    else if (letter == 'J' || letter == 'K' || letter == 'L')
                        result = result + "5";
                    else if (letter == 'M' || letter == 'N' || letter == 'O')
                        result = result + "6";
                    else if (letter == 'P' || letter == 'Q' || letter == 'R' || letter == 'S')
                        result = result + "7";
                    else if (letter == 'T' || letter == 'U' || letter == 'V')
                        result = result + "8";
                    else if (letter == 'W' || letter == 'X' || letter == 'Y' || letter == 'Z')
                        result = result + "9";
                    else if (letter == '1' || letter == '2' || letter == '3' || letter == '4' || letter == '5' || letter == '6' || letter == '7' || letter == '8' || letter == '9')
                        result = result + letter;
                    else
                        result = result + "1";
                }
            }
            formatNumber(ref result);
            numericPhoneLabel.Text = result;
        }

        // Format the display of the final result
        private void formatNumber(ref string result)
        {
            result = result.Insert(0, "(");

            result = result.Insert(4, ")");

            result = result.Insert(8, "-");
        }

        // User initialize the program by clicking button, retrieve data from user
        private void convertButton_Click(object sender, EventArgs e)
        {
            string alphabetPhoneNumber;
            alphabetPhoneNumber = telephoneTextBox.Text;

            if (checkValidNumber(alphabetPhoneNumber))
            {
                convertAlphabetToNumeric(alphabetPhoneNumber);
            }
            else
                numericPhoneLabel.Text = "Try Again.";
        }

        // Close the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
